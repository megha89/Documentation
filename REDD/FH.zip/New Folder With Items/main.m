% Replicate the demo in Section 4 of GCNU TR 2000-004 "Training Products of
% Experts by Minimizing Contrastive Divergence", Geoffrey E. Hinton.
% Iain Murray, July 2004, March 2006

rand('state',0);
randn('state',0);

more 'off'

% Power of floor 0-5
fid1 = fopen('Floor0_5_Power.csv');
line1 = textscan(fid1, '%*s %f', 'Delimiter', {',','\n'},'HeaderLines',54);
fclose(fid1);
A = cell2mat(line1);
data1 = A(1:168265);
data1 = data1(1:2:end,:);
nRows = size(data1,1);% number of data1 points in a row
D1 = size(data1,2);
N1 = 300; % number of samples
K1 = 2; 
rndIDX = randperm(nRows); 
data1 = data1(rndIDX(1:N1),:)'; 
data1 = (data1-min(data1(:))) ./ (max(data1(:)-min(data1(:))));
size(data1);

% Power of floor 6-11
fid2 = fopen('Floor6_11_Power.csv');
line2 = textscan(fid2, '%*s %f', 'Delimiter',{',','\n'},'HeaderLines',54);
fclose(fid2);
B = cell2mat(line2);
data2 = B(1:168265);
data2 = data2(1:2:end,:);
nRows = size(data2,1);% number of data2 points in a row
D2 = size(data2,2);
N2 = 300; % number of samples
K2 = 1; 
rndIDX = randperm(nRows); 
data2 = data2(rndIDX(1:N2),:)'; 
data2 = (data2-min(data2(:))) ./ (max(data2(:)-min(data2(:))));
size(data2);

% Total Power of floor 0-5 and floor 6-11
fid3 = fopen('TotalPower.csv');
line3 = textscan(fid3, '%*s %f', 'Delimiter', {',','\n'},'HeaderLines',54);
fclose(fid3);
C = cell2mat(line3);
test = C(1:168265);
test = test(1:2:end,:);
rows = size(test,1); % number of data3 points in a row
D3 = size(test,2); % no. of appliances
N3 = 300; % number of samples
K3 = 2; 
finaltest = test(1:N3)'
size(finaltest);
data3 = test(N3+1:rows)'
size(data3);
% uniform prior, into which one can absorb bias regularization, is over the unit square.
area=1;

% Step-size for naivish stochastic steepest-descent learning
epsilon=1/N1;

% Initialise everything else
mix=repmat(0.5,1,K1); % 1xK mixing proportions
LTmix=log(mix./(1-mix)); % logit basis
prec=1./repmat(mean(diag(cov(data1'))),D1,K1); % DxK precisions
Lprec=log(prec);
mu=randn(D1,K1)./sqrt(prec)+repmat(0.5,D1,K1);% DxK means
mu = abs((mu-mean(mu(:))) ./ (max(data1(:)-min(data1(:)))));
Lprec_old=Lprec; mu_old=mu; LTmix_old=LTmix;

[LTmix1,mu1,Lprec1] = training(LTmix,mu,Lprec,area,data1,prec,Lprec_old,mu_old,LTmix_old,epsilon);
disp(LTmix1)
disp(mu1)
disp(Lprec1)
disp(area)
disp(finaltest)
[pgauss_data1,dLTmix1,dmu1,dLprec1,p_k1] = ug_grad(LTmix1,mu1,Lprec1,area,finaltest)
sumPgauss1 = sum(pgauss_data1,2)
size(sumPgauss1)

% Initialise everything else
epsilon=1/N2;
mix=repmat(0.5,1,K2); % 1xK mixing proportions
LTmix=log(mix./(1-mix)); % logit basis
prec=1./repmat(mean(diag(cov(data2'))),D2,K2); % DxK precisions
Lprec=log(prec);
mu=randn(D2,K2)./sqrt(prec)+repmat(0.5,D2,K2);% DxK means
mu = abs((mu-mean(mu(:))) ./ (max(data2(:)-min(data2(:)))));
Lprec_old=Lprec; mu_old=mu; LTmix_old=LTmix;

[LTmix,mu,Lprec] = training(LTmix,mu,Lprec,area,data2,prec,Lprec_old,mu_old,LTmix_old,epsilon);

[pgauss_data2] = ug_grad(LTmix,mu,Lprec,area,finaltest);
sumPgauss2 = sum(pgauss_data2,2)
size(sumPgauss2)


prodPgauss = (sumPgauss1).* (sumPgauss2)
size(prodPgauss)

% Initialise everything else
epsilon=1/N3;
mix=repmat(0.5,1,K3); % 1xK mixing proportions
LTmix=log(mix./(1-mix)); % logit basis
prec=1./repmat(mean(diag(cov(data3'))),D3,K3); % DxK precisions
Lprec=log(prec);
mu=randn(D3,K3)./sqrt(prec)+repmat(0.5,D3,K3);% DxK means
mu = abs((mu-mean(mu(:))) ./ (max(data3(:)-min(data3(:)))));
Lprec_old=Lprec; mu_old=mu; LTmix_old=LTmix;

[LTmix,mu,Lprec] = training(LTmix,mu,Lprec,area,data3,prec,Lprec_old,mu_old,LTmix_old,epsilon);

[pgauss_data3] = ug_grad(LTmix,mu,Lprec,area,finaltest);
sumPgauss3 = sum(pgauss_data3,2);
size(sumPgauss3)






% fprintf('\nDone. Now showing final plot with original data, fantasy and expert ellipses\n');
% plotstuff(data,fantasy,mu,prec);
% P = p_k_data;
% Q = p_k_fantasy;
% T = p_k_test;
% 
 Distance1 = KLDiv(sumPgauss3,prodPgauss);
 Perf = mean(Distance1(:))
% Distance2 = KLDiv(P,T);
% Perf = mean(Distance2(:))
% disp(size(data))
% 
% clear;
