function [ LTmix1,mu1,Lprec1 ] = training(LTmix,mu,Lprec,area,data,prec,Lprec_old,mu_old,LTmix_old,epsilon)

terminatenow=0;
maxstep=0;
iter=0;
while ~terminatenow
%while (iter < 1)
	iter=iter+1;
	fprintf('Iteration %d   maxstep=%g       \r',iter,maxstep);
	
	% Compute first term of gradient
	[pgauss,dLTmix0,dmu0,dLprec0,p_k_data]=ug_grad(LTmix,mu,Lprec,area,data);
	
	% Second term from fantasy
	fantasy=sample_hidden(pgauss,mu,prec);
	[dummy,dLTmix1,dmu1,dLprec1]=ug_grad(LTmix,mu,Lprec,area,fantasy);
	
	% Move along gradient
	deltaLTmix=epsilon*(dLTmix0-dLTmix1);
	LTmix=LTmix+deltaLTmix;
	%
	deltamu=epsilon*(dmu0-dmu1);
	deltamu=deltamu./prec; % pseudo-natural-gradient hack
	mu=mu+deltamu;
	%
	deltaLprec=epsilon*(dLprec0-dLprec1);
	deltaLprec=deltaLprec.*(1-((Lprec>10)&(deltaLprec>0))); % disallow huge precisions
	Lprec=Lprec+deltaLprec;
	prec=exp(Lprec);

	% Hacky termination rule
	if (~mod(iter,100)) && (iter>5e3)
		maxstep=max(abs([LTmix(:)-LTmix_old(:);mu(:)-mu_old(:);Lprec(:)-Lprec_old(:)]));
		if maxstep<.109
			terminatenow=1;
		end
		Lprec_old=Lprec; mu_old=mu; LTmix_old=LTmix;
	end

	% Visualise
% 	if terminatenow||(~mod(iter,20))
% 		plotstuff(data,fantasy,mu,prec);
% 	end
end
LTmix1 = LTmix;
mu1 = mu;
Lprec1 = Lprec;

end

